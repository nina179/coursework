# Lab 1: Gitting Started

This repository contains the resources for your Lab 1 submission.  Modify these files according to the instructions on the course website and then commit and push your changes using `git`.
